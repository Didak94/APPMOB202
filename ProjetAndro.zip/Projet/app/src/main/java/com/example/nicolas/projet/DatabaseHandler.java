package com.example.nicolas.projet;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Jean-Jacques on 10/03/2016.
 */
public class DatabaseHandler extends SQLiteOpenHelper {

    public static final String USER_KEY = "id_user";
    public static final String USER_PRENOM = "prenom";
    public static final String USER_NOM = "nom";
    public static final String USER_LOGIN = "login";
    public static final String USER_PASSWORD = "password";

    public static final String FAVORI_KEY = "id_favori";
    public static final String FAVORI_NOM = "nom_favori";
    public static final String FAVORI_REGION = "region_favori";

    public static final String FAVORISER_KEY = "id_favorisation";


    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "baseProjet";

    public static final String USER_TABLE_NAME = "USER";
    public static final String FAVORI_TABLE_NAME = "FAVORI";
    public static final String FAVORISER_TABLE_NAME = "FAVORISER";


    public static final String USER_TABLE_CREATE =
            "CREATE TABLE " + USER_TABLE_NAME + " (" +
                    USER_KEY + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    USER_PRENOM + " TEXT, " +
                    USER_NOM + " TEXT, " +
                    USER_LOGIN + " TEXT, " +
                    USER_PASSWORD + " TEXT);";


    public static final String FAVORI_TABLE_CREATE =
            "CREATE TABLE " + FAVORI_TABLE_NAME + " (" +
                    FAVORI_KEY + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    FAVORI_NOM + " TEXT, "+
                    FAVORI_REGION + " TEXT);";


    public static final String FAVORISER_TABLE_CREATE =
            "CREATE TABLE " + FAVORISER_TABLE_NAME + " (" +
                    FAVORISER_KEY + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    USER_KEY + " INTEGER, " +
                    FAVORI_KEY + " INTEGER);";

    public DatabaseHandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(USER_TABLE_CREATE);
        db.execSQL(FAVORI_TABLE_CREATE);
        db.execSQL(FAVORISER_TABLE_CREATE);

    }




    public static final String USER_TABLE_DROP = "DROP TABLE IF EXISTS " + USER_TABLE_NAME + ";";

    public static final String FAVORI_TABLE_DROP = "DROP TABLE IF EXISTS " + FAVORI_TABLE_NAME + ";";

    public static final String FAVORISER_TABLE_DROP = "DROP TABLE IF EXISTS " + FAVORISER_TABLE_NAME + ";";

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(USER_TABLE_DROP);
        db.execSQL(FAVORI_TABLE_DROP);
        db.execSQL(FAVORISER_TABLE_DROP);
        onCreate(db);
    }


//Méthodes pour manipuler et utiliser la BDD

    public void ajouterUser(User u){

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        //values.put(USER_KEY, u.getId());
        values.put(USER_PRENOM, u.getPrenom());
        values.put(USER_NOM, u.getNom());
        values.put(USER_LOGIN, u.getLogin());
        values.put(USER_PASSWORD, u.getPassword());


        // Inserting Row
        db.insert(USER_TABLE_NAME, null, values);
        db.close(); // Closing database connection

    }

    public User getUser(int id_user){
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(USER_TABLE_NAME, new String[] { USER_KEY,
                        USER_PRENOM, USER_NOM , USER_LOGIN, USER_PASSWORD }, USER_KEY + "=?",
                new String[] { String.valueOf(id_user) }, null, null, null, null);
        if (cursor != null)
            cursor.moveToFirst();

        User user = new User(Integer.parseInt(cursor.getString(0)),
                cursor.getString(1), cursor.getString(2), cursor.getString(3), cursor.getString(4));
        return user;
    }

    public List<User> getAllUser() {
        List<User> userList = new ArrayList<User>();
        // Select All Query
        String selectQuery = "SELECT  * FROM " + USER_TABLE_NAME;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                User user =
                        new User(Integer.parseInt(cursor.getString(0)),cursor.getString(1),cursor.getString(2),
                                cursor.getString(3),cursor.getString(4));
                // Adding contact to list
                userList.add(user);
            } while (cursor.moveToNext());
        }

        // return contact list
        return userList;
    }

    public void supprimerUser(User u){
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(USER_TABLE_NAME, USER_KEY + " = ?",
                new String[]{String.valueOf(u.getId())});
        db.close();

    }

    public void ajouterFavori(Favori f){

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(FAVORI_KEY, f.getId_favori());
        values.put(FAVORI_NOM, f.getNom_favori());
        values.put(FAVORI_REGION, f.getRegion_favori());

        // Inserting Row
        db.insert(FAVORI_TABLE_NAME, null, values);
        db.close(); // Closing database connection

    }

    public void supprimerFavori(Favori f){
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(FAVORI_TABLE_NAME, FAVORI_KEY + " = ?",
                new String[]{String.valueOf(f.getId_favori())});
        db.close();

    }


    public void ajouterFavoriser(JoueurFavorisé f){

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(FAVORISER_KEY, f.getId_favorisant());
        values.put(USER_KEY, f.getId_user());
        values.put(FAVORI_KEY, f.getId_favori());


        // Inserting Row
        db.insert(FAVORISER_TABLE_NAME, null, values);
        db.close(); // Closing database connection

    }

    public List<JoueurFavorisé> getAllJoueurFavorisé() {
        List<JoueurFavorisé> favoriserList = new ArrayList<JoueurFavorisé>();
        // Select All Query
        String selectQuery = "SELECT  * FROM " + FAVORISER_TABLE_NAME;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                JoueurFavorisé joueur =
                        new JoueurFavorisé(Integer.parseInt(cursor.getString(0)),Integer.parseInt(cursor.getString(1)),
                                Integer.parseInt(cursor.getString(3)));
                // Adding contact to list
                favoriserList.add(joueur);
            } while (cursor.moveToNext());
        }

        // return contact list
        return favoriserList;
    }

    public void supprimerFavoriser(JoueurFavorisé f){
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(FAVORISER_TABLE_NAME, FAVORISER_KEY + " = ?",
                new String[]{String.valueOf(f.getId_favorisant())});
        db.close();

    }





}
