package com.example.nicolas.projet;

/**
 * Created by Jean-Jacques on 10/03/2016.
 */
public class Favori {

    private int id_favori;
    private String nom_favori;
    private String region_favori;

    public void setRegion_favori(String region_favori) {
        this.region_favori = region_favori;
    }

    public Favori(int id_favori, String nom_favori, String region_favori) {

        this.id_favori = id_favori;
        this.nom_favori = nom_favori;
        this.region_favori = region_favori;
    }

    public int getId_favori() {
        return id_favori;
    }

    public void setId_favori(int id_favori) {
        this.id_favori = id_favori;
    }

    public String getNom_favori() {
        return nom_favori;
    }

    public void setNom_favori(String nom_favori) {
        this.nom_favori = nom_favori;
    }

    public String getRegion_favori() {
        return region_favori;
    }
}
