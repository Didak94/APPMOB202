package com.example.nicolas.projet;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.*;
import net.rithms.riot.api.RiotApi;
import net.rithms.riot.api.RiotApiException;
import net.rithms.riot.constant.Region;
import net.rithms.riot.dto.Champion.ChampionList;
import net.rithms.riot.dto.Static.Champion;
import net.rithms.riot.dto.Stats.AggregatedStats;
import net.rithms.riot.dto.Stats.RankedStats;
import net.rithms.riot.dto.Summoner.Summoner;



import java.text.DecimalFormat;

public class AffichageSummoner extends AppCompatActivity {
    private static Summoner summoner;
    private static Region region;
    private static boolean introuvable;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_affichage_summoner);
        Bundle extras = getIntent().getExtras();

        final String summonerName = extras.get("extraName").toString();
        final String region = extras.get("extraRegion").toString();
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                final RiotApi api = new RiotApi("d4c34859-2e5d-425c-904c-461fc1128212");
                switch (region) {
                    case "EUW":
                        api.setRegion(Region.EUW);
                        Log.i("AffichageSummoner", "Region EUW");
                        break;
                    case "EUNE":
                        api.setRegion(Region.EUNE);
                        Log.i("AffichageSummoner", "Region EUNE");
                        break;
                    case "NA":
                        api.setRegion(Region.NA);
                        Log.i("AffichageSummoner", "Region NA");
                        break;
                    case "KR":
                        api.setRegion(Region.KR);
                        Log.i("AffichageSummoner", "Region KR");
                        break;
                    case "BR":
                        api.setRegion(Region.BR);
                        Log.i("AffichageSummoner", "Region BR");
                        break;
                    case "LAN":
                        api.setRegion(Region.LAN);
                        Log.i("AffichageSummoner", "Region LAN");
                        break;
                    case "LAS":
                        api.setRegion(Region.LAS);
                        Log.i("AffichageSummoner", "Region LAS");
                        break;
                    case "RU":
                        api.setRegion(Region.RU);
                        Log.i("AffichageSummoner", "Region RU");
                        break;
                    case "OCE":
                        api.setRegion(Region.OCE);
                        Log.i("AffichageSummoner", "Region OCE");
                        break;
                    case "TR":
                        api.setRegion(Region.TR);
                        Log.i("AffichageSummoner", "Region TR");
                        break;
                    default:
                        Log.i("Error", "Mauvaise région");
                }

                Summoner summoner = null;
                try {
                    summoner = api.getSummonerByName(summonerName);
                } catch (RiotApiException e) {
                    e.printStackTrace();

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {

                            TextView tv = (TextView) findViewById(R.id.textJoueurIntrouvable);
                            tv.setVisibility(View.VISIBLE);
                            //utilisateur introuvable
                            introuvable = true;
                        }
                    });
                }
                Log.i("AffichageSummoner", "trouvé : " + introuvable);
                //Log.i("AffichageSummoner", "Summoner level : " + summoner.getSummonerLevel());
                //Log.i("AffichageSummoner", "Id : " + summoner.getId());
                final TextView tvSummonerName = (TextView) findViewById(R.id.textSummonerName);

                final TextView tvSummonerLvl = (TextView) findViewById(R.id.textSummonerLvl);
                final ImageView ivProfileIcon = (ImageView) findViewById(R.id.imageViewProfileIcon);

                if(!introuvable) {
                    try {
                        RankedStats rankedStats = api.getRankedStats(summoner.getId());

                        final DecimalFormat df = new DecimalFormat("##.##");
                        float w = 0;
                        float l = 0;
                        int nbPlayed = 0;
                        int idChampion = 0;
                        Champion c;
                        for (int i = 0; i < rankedStats.getChampions().size(); i++) {
                            if (rankedStats.getChampions().get(i).getStats().getTotalSessionsPlayed() > nbPlayed && i < rankedStats.getChampions().size() - 1) {
                                idChampion = rankedStats.getChampions().get(i).getId();
                                nbPlayed = rankedStats.getChampions().get(i).getStats().getTotalSessionsPlayed();
                                Log.i("AffichageSummoner", "IdChampion = " + idChampion);
                                Log.i("AffichageSummoner", "Joué = " + rankedStats.getChampions().get(i).getStats().getTotalSessionsPlayed());

                            }
                            w += rankedStats.getChampions().get(i).getStats().getTotalSessionsWon();
                            l += rankedStats.getChampions().get(i).getStats().getTotalSessionsLost();

                        }
                        Log.i("AffichageSummoner", "IdChampion = " + idChampion);
                        c = api.getDataChampion(idChampion);
                        final String nomChampion = c.getName();
                        final String keyChampion = c.getKey();


                        //http://ddragon.leagueoflegends.com/cdn/4.2.6/img/champion/Aatrox.png

                        float played = w + l;
                        final float ratio;
                        if (l != 0) {
                            ratio = (w / played) * 100;
                        } else {
                            ratio = 0;
                        }

                        final int wins = (int) w;
                        final int losses = (int) l;
                        final String summonerName = summoner.getName();
                        final long summonerLvl = summoner.getSummonerLevel();
                        final TextView tvWinrate = (TextView) findViewById(R.id.textWinrateRatio);
                        final TextView tvChampion = (TextView) findViewById(R.id.tvChampion);
                        final ImageView ivChampion = (ImageView) findViewById(R.id.ivIconChampion);
                        final Button btnFavori = (Button) findViewById(R.id.btnFavori);
                        final int profileIconId = summoner.getProfileIconId();
                        final int nbPlayed2 = nbPlayed;
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {

                                tvSummonerName.setText(summonerName);
                                tvSummonerLvl.setText("Niveau " + Long.toString(summonerLvl));
                                tvWinrate.setText("Winrate : " + df.format(ratio) + "% (" + wins + " - " + losses + ")");
                                if (ratio < 50) {
                                    tvWinrate.setTextColor(getResources().getColorStateList(R.color.lightRed));
                                } else {
                                    tvWinrate.setTextColor(getResources().getColorStateList(R.color.lightGreen));
                                }
                                tvChampion.setText("Champion le plus joué : (" + nbPlayed2 + " games) \n" + nomChampion);
                                //Picasso.with(getApplicationContext()).load("http://ddragon.leagueoflegends.com/cdn/5.15.1/img/profileicon/" + profileIconId + ".png").into(ivProfileIcon);

                                Picasso.with(getApplicationContext()).load("http://ddragon.leagueoflegends.com/cdn/6.5.1/img/profileicon/" + profileIconId + ".png").into(ivProfileIcon);

                                Picasso.with(getApplicationContext()).load("http://ddragon.leagueoflegends.com/cdn/6.5.1/img/champion/" + keyChampion + ".png").into(ivChampion);
                                tvChampion.setVisibility(View.VISIBLE);
                                ivChampion.setVisibility(View.VISIBLE);
                                btnFavori.setVisibility(View.VISIBLE);
                                tvSummonerLvl.setVisibility(View.VISIBLE);
                                tvSummonerName.setVisibility(View.VISIBLE);
                                tvWinrate.setVisibility(View.VISIBLE);
                                ivProfileIcon.setVisibility(View.VISIBLE);

                            }
                        });
                    } catch (RiotApiException e) {
                        e.printStackTrace();
                        Log.i("AffichageSummoner", "Pas de ranked trouvée");
                    }
                }





            }

        });

        thread.start();

                /*runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Summoner summoner = null;
                        try {
                            summoner = api.getSummonerByName(summonerName);
                        } catch (RiotApiException e) {
                            e.printStackTrace();
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {

                                    TextView tv = (TextView) findViewById(R.id.textJoueurIntrouvable);
                                    tv.setVisibility(View.VISIBLE);
                                    //utilisateur introuvable

                                }
                            });
                        }
                        Log.i("AffichageSummoner", "Summoner level : " + summoner.getSummonerLevel());
                        Log.i("AffichageSummoner", "Id : " + summoner.getId());
                        final TextView tvSummonerName = (TextView) findViewById(R.id.textSummonerName);
                        tvSummonerName.setText(summoner.getName());

                        final TextView tvSummonerLvl = (TextView) findViewById(R.id.textSummonerLvl);
                        tvSummonerLvl.setText("Niveau " + Long.toString(summoner.getSummonerLevel()));

                        RankedStats rankedStats = null;
                        try {
                            rankedStats = api.getRankedStats(summoner.getId());
                        } catch (RiotApiException e) {
                            e.printStackTrace();
                        }
                        AggregatedStats allChampionsStats = rankedStats.getChampions().get(0).getStats();
                        int wins = allChampionsStats.getTotalSessionsWon();
                        int losses = allChampionsStats.getTotalSessionsLost();
                        int ratio = wins / losses;
                        final TextView tvWinrate = (TextView) findViewById(R.id.textWinrateRatio);
                        tvWinrate.setText("Winrate : " + ratio + "% (" + wins + " - " + losses);

                        tvSummonerLvl.setVisibility(View.VISIBLE);
                        tvSummonerName.setVisibility(View.VISIBLE);
                        tvWinrate.setVisibility(View.VISIBLE);

                    }
                });



*/
    }





}



