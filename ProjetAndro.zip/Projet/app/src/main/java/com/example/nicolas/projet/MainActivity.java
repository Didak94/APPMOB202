package com.example.nicolas.projet;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.Map;
import net.rithms.riot.constant.Region;
import net.rithms.riot.dto.Static.Champion;
import net.rithms.riot.dto.Stats.AggregatedStats;
import net.rithms.riot.dto.Stats.RankedStats;
import net.rithms.riot.dto.Summoner.Summoner;
import net.rithms.riot.api.RiotApi;
import net.rithms.riot.api.RiotApiException;
import com.google.gson.*;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Thread thread = new Thread(new Runnable(){
            @Override
            public void run() {
                try {
                    RiotApi api = new RiotApi("d4c34859-2e5d-425c-904c-461fc1128212");
                    api.setRegion(Region.EUW);

                    try {
                        Summoner summoner = api.getSummonerByName("awK");

                        long id = summoner.getId();
                        String sid = Long.toString(id);
                        String name = summoner.getName();
                        Log.i("Projet", "id = " + sid);
                        Log.i("Projet", "name = " + name);
                        Log.i("Projet", "Profile icon id = " + summoner.getProfileIconId());

                        RankedStats rankedStats = api.getRankedStats(summoner.getId());
                        //AggregatedStats allChampionsStats = rankedStats.getChampions().get(0).getStats();
                        int wins = 0;
                        int losses = 0;
                        for(int i = 0; i < rankedStats.getChampions().size(); i++){
                            wins += rankedStats.getChampions().get(i).getStats().getTotalSessionsWon();
                            losses += rankedStats.getChampions().get(i).getStats().getTotalSessionsLost();

                        }
                        Log.i("Projet", "losses = " + losses);
                        Log.i("Projet", "wins = " + wins);

                        System.out.println(sid);
                    } catch (RiotApiException e) {
                        e.printStackTrace();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        thread.start();




    }

    public void sendMessage(View view){
        Intent intent = new Intent(MainActivity.this, AffichageSummoner.class);


        EditText summonerNameET = (EditText) findViewById(R.id.summonerName);
        Spinner regionS = (Spinner) findViewById(R.id.spinner);
        regionS.getSelectedItem().toString();
        String region = regionS.getSelectedItem().toString();
        String summonerName = summonerNameET.getText().toString();
        Log.i("Projet", "nom user = " + summonerName);
        Log.i("Projet", "region = " + region);
        intent.putExtra("extraName", summonerName);
        intent.putExtra("extraRegion", region);
        startActivity(intent);


    }

    public void clearText(View view){
        EditText editText = (EditText) findViewById(R.id.summonerName);
        editText.setText("");
    }







}