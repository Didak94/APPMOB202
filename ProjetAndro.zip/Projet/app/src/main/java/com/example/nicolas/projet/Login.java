package com.example.nicolas.projet;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;



import java.util.List;

public class Login extends AppCompatActivity {

    Button b1,b2;
    EditText ed1,ed2;

    AutoCompleteTextView ac;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login2);


        DatabaseHandler dbu = new DatabaseHandler(this);

        b1=(Button) findViewById(R.id.Blogin);


        dbu.ajouterUser(new User(1, "freddie", "frost", "fred@jon.fr", "frost"));
        //dbu.ajouterFavoriser(new JoueurFavorisé(0, 0, 0));
        //dbu.ajouterFavori(new Favori());

        List<User> users = dbu.getAllUser();


        ed1=(EditText)findViewById(R.id.extractEditText);
        ed2=(EditText)findViewById(R.id.extractEditText2);

        /*if(ed1.getText().equals("fred@jon.fr")&&ed2.getText().equals("frost")){


        b1.setOnClickListener(new View.OnClickListener(){


            @Override
            public void onClick(View v) {

            Intent intent = new Intent(Login.this,
                    MainActivity.class);
            //intent.putExtra(EXTRA_LOGIN,loginTxt);
            //intent.putExtra(EXTRA_PASSWORD,passTxt);

            startActivity(intent);}


        });
        }*/



    }
    public void onButtonClick(View v){

            if (v.getId() == R.id.Blogin) {

                Intent intent = new Intent(Login.this,
                        MainActivity.class);
                startActivity(intent);
            }
        }


}