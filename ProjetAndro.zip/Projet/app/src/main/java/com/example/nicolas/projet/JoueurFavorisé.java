package com.example.nicolas.projet;

/**
 * Created by Jean-Jacques on 10/03/2016.
 */
public class JoueurFavorisé {

    private int id_favorisant;
    private int id_user;
    private int id_favori;

    public JoueurFavorisé(int id_favorisant, int id_user, int id_favori) {
        this.id_favorisant = id_favorisant;
        this.id_user = id_user;
        this.id_favori = id_favori;
    }

    public int getId_favorisant() {
        return id_favorisant;
    }

    public void setId_favorisant(int id_favorisant) {
        this.id_favorisant = id_favorisant;
    }

    public int getId_user() {
        return id_user;
    }

    public void setId_user(int id_user) {
        this.id_user = id_user;
    }

    public int getId_favori() {
        return id_favori;
    }

    public void setId_favori(int id_favori) {
        this.id_favori = id_favori;
    }
}
